# Constantes son valores que nunca van a cambiar en el programa
# PI = 3.1416
# MAYUSCULA SOSTENIDA

# CONSTANTES DEL MET Estos son los valores del MET
CAMINAR = 2
TENIS = 5
MONTAR_BICICLETA = 14
CORRER = 6
NADAR = 9.8

# constantes de masa corporal
PORCENTAJE = 50


def ejemplo(saludo):
  print("usted caminó  ", CAMINAR , " minutos")

ejemplo("hola, ")

#########################################

pesoHombre = input("digite su peso")

IVA = 19

caloríasQuemadasCaminando = (20 * CAMINAR * 80) /200

print("el iva para el 2022 es ", IVA)


IVA = 10
print("el iva para el 2023 es ", IVA)




SDF
SF
SD
F
SD
F
SDF
SD
F
SDF
SD
F
SDF
S
DF
SD
F
SD
F
SDF
S
F
SD
F


PORCENTAJE * CAMINAR


