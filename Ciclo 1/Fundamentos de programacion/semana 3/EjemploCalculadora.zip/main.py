def pesoIdealHombre(altura):
  hombre = 56.2 +1.41*(altura/2.54 -60)
  return hombre

def pesoIdealMujer(altura):
  mujer = 53.1 +1.36 *(altura/2.54 -60)
  return mujer

def caloriasQuemadasPorCaminar(tiempo, peso):
  caloriasQuemadas = (tiempo * 2 * peso) /200
  return caloriasQuemadas

def caloriasQuemadasPorJugarTenis(tiempo, peso):
  caloriasQuemadas = (tiempo * 5 * peso) /200
  return caloriasQuemadas

#######################
print("PAra calcular el peso ideal, por favor digite la altulra:")
alturaPersona = float(input())

print("EL peso ideal para el hombre seria: ", pesoIdealHombre(alturaPersona))
print("EL peso ideal para el mujer seria: ", pesoIdealMujer(alturaPersona))

tiempoCaminar = 20
peso = 80

print("Calorias al caminar serían " , caloriasQuemadasPorCaminar(tiempoCaminar,                           pesoIdealHombre(alturaPersona)))
print("Calorias al jugar Tennis serían " , caloriasQuemadasPorJugarTenis(tiempoCaminar,                           pesoIdealHombre(alturaPersona)))


def menuAtividades():
  print("1.Caminar")
  print("2.Jugar Tenis")





