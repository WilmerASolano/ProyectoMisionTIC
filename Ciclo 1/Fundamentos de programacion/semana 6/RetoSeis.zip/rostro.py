import os 
import menu as mn
import estilos as es

rostro=[[],[],[],[],[]]

def pelo(resPelo):
  #pelo=[]
 if (resPelo==1) :
    rostro[0].append("WWWWWWWWW")
    os.system("clear")
    print(rostro[0])
    es.estiOjos()

 if (resPelo==2 ):
    rostro[0].append("||||||||")
    os.system("clear")
    print(rostro[0])
    es.estiOjos()
 if(resPelo==3):
    rostro[0].append("|'''''''|")
    os.system("clear")
    print(rostro[0])
    es.estiOjos()
 if(resPelo==4):
    rostro[0].append("\\\/////")
    os.system("clear")
    print(rostro[0])
    es.estiOjos()
 if (resPelo> 4):
  mn.verMenu()

######################################################
######################################################
######################################################
def ojos(res):
  #print("invoco la funcion")
  if (res== 1 ):
    rostro[1].append("|  @  @  |")
    os.system("clear")
    print(rostro[1])
    es.estiOrejas()
    
 
  if(res==2 ):
    rostro[1].append("| =(. .) =|")
    os.system("clear")
    print(rostro[1])
    es.estiOrejas()
  if(res==3 ):
    rostro[1].append("| =(0 0)= |")
    os.system("clear")
    print(rostro[1])
    es.estiOrejas()
    
  if(res==4 ):
    rostro[1].append("|   \/   |")
    os.system("clear")
    print(rostro[1])
    es.estiOrejas()

  
  
######################################################
######################################################
######################################################
def orejas(res):
 if(res==1 ):
   rostro[2].append("@    U    @")
   os.system("clear")
   print(rostro[2])
   es.estiBoca()
 if(res==2):
    rostro[2].append("{   ==    }")
    os.system("clear")
    print(rostro[2])
    es.estiBoca()
 if(res==3):
    rostro[2].append("[    J   ]")
    os.system("clear")
    print(rostro[2])
    es.estiBoca()
 if(res==4):
    rostro[2].append("|   ---   |")
    os.system("clear")
    print(rostro[2])
    es.estiBoca()
######################################################
######################################################
######################################################

def boca(res):
  if(res==1):
    rostro[3].append("|   ==   |")
    os.system("clear")
    print(rostro[3])
    es.estiCuello()
  if(res==2):
    rostro[3].append("|    =    |")
    os.system("clear")
    print(rostro[3])
    es.estiCuello()
  if(res==3):
    rostro[3].append("|   ___   |")
    os.system("clear")
    print(rostro[3])
    es.estiCuello()
  if(res==4):
    rostro[3].append("|   ---   |")
    os.system("clear")
    print(rostro[3])
    es.estiCuello()
######################################################
######################################################
######################################################   
def cuello(res):  
  if(res==1):
    rostro[4].append("\________/")
    print(rostro[4])
    os.system("clear")
    cara()
######################################################
######################################################
######################################################  
  
def cara():
 print("este es tu rostro")
 for i in range(len(rostro)):
   for j in range(len(rostro[i])):
     print(rostro[i][j])
 print("antes de guardar el rostro")
 print("te gusto tu rostro")
 rta = input("si o no: ")
 if(rta == "si"):
   os.system("clear")
   archivoRostro()
 else:
   os.system("clear")
   es.estiPelo()
######################################################
######################################################
######################################################  
  
def archivoRostro():
  print("digita el nombre como desea que se guarde el rostro ")
  nom = input("nombre: ")
  nomArchivoRostro= str(nom)+".txt"
  with open(nomArchivoRostro,"w") as file:
   archivo = "".join([str(_) for _ in rostro])
   file.write(archivo)
   file.write("\n")
   os.system("clear")
   print("tu archivo del rostro fue creado con exito")
######################################################
######################################################
######################################################  
  
def consulArchivo():
  nombre = input("digita nombre rostro: ")
  nomArch=  str(nombre)+".txt"
  try:
   file = open(nomArch, "r")
   file.close()
  except FileNotFoundError as e:
   print("El archivo no existe:",  e)
  finally:
   print("Se cierra el archivo")
   if file:
    file.close()