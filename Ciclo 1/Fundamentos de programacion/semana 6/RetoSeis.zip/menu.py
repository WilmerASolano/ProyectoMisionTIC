import os
import estilos as es
def verMenu():
    print("------------- Menu del rostro -------------")
    print("")
    print("")
    print("1. Seleccion de cabello")
    print("2. Seleccion de ojos") 
    print("3. Seleccion de orejas y nariz")
    print("4. Seleccion de boca")
    print("5. Observar rostro")
    op = int(input("Digite la opción [1..4]:  "))
    if (op >= 1):
     # return op
      es.estiPelo()
    else:
      print("debe ser una  opción del menu entre 1..4")
  