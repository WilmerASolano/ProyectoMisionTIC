Solucion reto numero cuatro metodo ideal 

Identificar el problema: 
el programa worldcraft crea rostros de jugador y criaturas
Definir el problema: 
un programa que permita al usuario crear un rostro como tamto de jugador como de criaturas 
Estrategia:
crear un menu donde el jugador seleccione las partes  y que la misma se vaya elaborando lo muestre y si es de su gusto se guarde en un archivo
el rostro se va a guardar en una matriz
cada parte de rostro se elaborara en una funcion independiente
el archivo lo generara en funciones que tiene asignado el programa python
Algoritmos:
se van a generar funciones para:
*Elaboracion del cabello
*Elaboracion de orejas y nariz
*Elaboracion de labios
*Elaboracion del cuello
cada uno muestra opciones de seleccion para el usuario
cada uno se va guardar en una matriz principal llamada rostro de cinco posiciones
cuando el rostro este completo lo mostrara en pantalla
si es del gusto del usuario se le pedira el nombre para guardar el rostro en un archivo donde esta se guarde y pueda ser buscada 
sino es asi lo mandara automaticamente a que vuelva a elaborar el rostro segun sus preferencias 