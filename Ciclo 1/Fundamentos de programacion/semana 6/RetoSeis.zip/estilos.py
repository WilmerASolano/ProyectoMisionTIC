import rostro as rs
def estiPelo():
    print("estilos de pelo disponible")
    print("1. Pelo denso WWWWWWWWWW")
    print("2. Pelo escaso |||||||||")
    print("3.Pelo rapado |''''''''|")
    print("4.Pelo a raya  \\\\///// ")
    resPelo = int(input("digita opcion: "))
    rs.pelo(resPelo)

def estiOjos():
  print("estilos de ojos disponible")
  print("1. Ojos grandes |  @  @  |")
  print("2. Ojos pequeños y gafas | =(. .)= |")
  print("3.Ojos grandes y gafas | =(0 0)= |")
  print("4.Ojos enojados |   \/   |")
  resOjos = int(input("digita opcion: "))
  rs.ojos(resOjos)
  
def estiOrejas():
  print("estilos de orejas y narices disponibles")
  print("1. Orejas arroba y nariz grande @   J   @")
  print("2. Orejas llaves y nariz redonda {  =   } ")
  print("3.Orejas corchetes y nariz en J [   J    ]")
  print("4.Ojos triangulos y nariz ancha <  ---  >")
  res = int(input("digita opcion: "))
  rs.orejas(res)
def estiBoca():
  print("estilos de boca disponibles")
  print("1.Boca |  ===  |")
  print("2.Boca |  ____ |")
  print("3.Boca |  __  |")
  print("4.Boca |  ---- |")
  res = int(input("digita opcion: "))
  rs.boca(res)
def estiCuello():
  print("estilos de cuello disponible")
  print("1.Cuello  \______/")
  res = int(input("digita opcion: "))
  rs.cuello(res)
def cara():
 rs.cara()