import os 
import estilos as es
import menu
import rostro as rs

#op = menu.verMenu()
#while (True):
#def verMenu():
print("------------- Menu del rostro -------------")
print("")
print("si se va a crear por primera vez el rostro")
print("este se va a realizar en orden")
print("por favor digite 1 y empezamos a hacer el rostro")
print("1. Seleccion de cabello")
print("2. Seleccion de ojos") 
print("3. Seleccion de orejas y nariz")
print("4. Seleccion de boca")
print("5. Consultar rostro")
op = int(input("Digite la opción [1..5]:  "))
if (op == 1):
 os.system("clear")
 es.estiPelo()
  #print("sassd")
if (op == 2 ):
  os.system("clear")
  es.estiOjos()
if(op==3):
  os.system("clear")
  es.estiOrejas()
if(op==4):
  os.system("clear")
  es.estiBoca()
if (op == 5):
  os.system("clear")
  rs.consulArchivo()
else: 
  input()
  print("debe ser una  opción del menu entre 1..4")








