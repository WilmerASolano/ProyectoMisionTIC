package com.mycompany.universidadmintic75.controllers;

public class EstudianteController {
    public void misCursos(){
        //TODO
    }
}
