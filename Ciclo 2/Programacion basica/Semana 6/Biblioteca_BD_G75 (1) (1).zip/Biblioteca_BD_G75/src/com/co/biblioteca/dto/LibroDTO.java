package com.co.biblioteca.dto;

public class LibroDTO {
    private int libroID;
    private String titulo;
    
}
